require 'sinatra'
require 'sqlite3'

get('/') do
	erb(:index)
end

get('/main') do
	db = SQLite3::Database.new("./fields.db")
	fields = db.execute("SELECT * FROM Fields")
	erb(:main, locals:{fields:fields})
end

get('/list') do
	db = SQLite3::Database.new("./fields.db")
	fields = db.execute("SELECT * FROM Fields")
	ratings = db.execute("SELECT * FROM Rankings")
	fields.each do |field|
		db.execute("update Fields set ratings = (SELECT count(*) FROM Rankings where field_id = #{field[0]}) where id = #{field[0]}") 
	end
		erb(:list, locals:{fields:fields, rankings:ratings})
end

get('/review/:field') do
	db = SQLite3::Database.new("./fields.db")
	field = params[:field]
	field_id = db.execute("SELECT id FROM Fields WHERE name = ('#{params[:field]}')")[0][0]
	reviews = db.execute("SELECT * FROM Rankings where field_id = #{field_id}")
	erb(:review, locals:{field:field, reviews:reviews})
end

post('/review/:field') do
	db = SQLite3::Database.new("./fields.db")
	fields = db.execute("SELECT * FROM Fields")
	field_id = db.execute("SELECT id FROM Fields WHERE name = ('#{params[:field]}')")[0][0]
	db.execute("insert into Rankings (content,rating, field_id) VALUES (?,?,?)", [params["cont"], params["star"], field_id])
	db.execute("update Fields set ratings = (SELECT count(*) FROM Rankings where field_id = #{field_id}) where id = #{field_id}")
	db.execute("update Fields set avg = (SELECT avg(rating) FROM Rankings where field_id = #{field_id}) where id = #{field_id}")
	redirect('list')
end


