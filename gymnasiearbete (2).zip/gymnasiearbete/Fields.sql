BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS `Fields` (
	`id`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
	`name`	TEXT,
	`adress`	TEXT,
	`players`	TEXT,
	`material`	TEXT
);
INSERT INTO `Fields` VALUES (1,'Angeredsvallen','Högaffelsgatan 11','11','grass
');
INSERT INTO `Fields` VALUES (2,'Apelsinplan 1-2','Apelsingatan 6	
','11','grass,artificial');
INSERT INTO `Fields` VALUES (3,'Backavallen','Wadköpingsgatan 153','11, 7','artificial
');
INSERT INTO `Fields` VALUES (4,'Bergsjövallen','Sjustjärnan 20','11','grass,artificial');
INSERT INTO `Fields` VALUES (5,'Bergumsvallen','Grönkullavägen 21','11','grass,artificial');
INSERT INTO `Fields` VALUES (6,'Bläsebovallen','Bollplansgatan 12','11','artificial');
INSERT INTO `Fields` VALUES (7,'Bravida Arena','Inlandsgatan 48','11','artificial');
INSERT INTO `Fields` VALUES (8,'Donsövallen','Lurkenvägen 2','11','artificial');
INSERT INTO `Fields` VALUES (9,'Ekebäcksplan','Positivgatan 4 VÄSTRA FRÖLUNDA','9','grass');
INSERT INTO `Fields` VALUES (10,'Fjällboplan','Utbyvägen 16','-','grass');
INSERT INTO `Fields` VALUES (11,'Flatåsplan','Nymilsgatan 33','7','artificial');
INSERT INTO `Fields` VALUES (12,'Färjenäsplan','57.69739,11.90079','9','artificial');
INSERT INTO `Fields` VALUES (13,'Gamlestadsvallen','Lars Kaggsgatan 24','11,7','gravel,grass,artificial');
INSERT INTO `Fields` VALUES (14,'Generatorsplan','Minelundsvägen 14','11','gravel,grass');
INSERT INTO `Fields` VALUES (15,'Gröna Vallen','Svanebäcksgatan 16','11','artificial');
INSERT INTO `Fields` VALUES (16,'Guldheden Södra','Gibraltargatan 41','11','artificial');
INSERT INTO `Fields` VALUES (17,'Gunnaredsplan','Gunnaredsvallen 4','11','artificial');
INSERT INTO `Fields` VALUES (18,'Hagenplan','Hagens Prästväg 4','7','grass');
INSERT INTO `Fields` VALUES (19,'Hammarkulleplan','Hammarkullegatan 15','9','gravel');
INSERT INTO `Fields` VALUES (20,'Hedens bollplaner','Parkgatan 43','11,7','artificial');
INSERT INTO `Fields` VALUES (21,'Hjällbovallen','Knattens Väg 12','11,7','gravel,grass');
INSERT INTO `Fields` VALUES (22,'Hovgårdsvallen','Gamla Lillebyvägen 1','11','grass');
INSERT INTO `Fields` VALUES (23,'Hovåsvallen 1-2','Bockhamnsvägen 14','11','gravel,grass');
INSERT INTO `Fields` VALUES (24,'Härlanda planer','Kålltorpsgatan 4E','11,7','grass');
INSERT INTO `Fields` VALUES (25,'Karl Johanstorget','Karl Johanstorget 1','7','artificial');
INSERT INTO `Fields` VALUES (26,'Klarebergsvallen','Burmans Gata 3','11,7','grass,artificial');
COMMIT;
